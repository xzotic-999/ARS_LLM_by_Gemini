# ARS_LLM — Production Cloud Architecture & Remote FreeLLMAPI Integration

This plan decouples `ARS_LLM` production operation from the developer's local computer (`host.docker.internal` / `localhost:31415`), implements a unified single-container deployment serving both the compiled React SPA and the Express API backed by Cloud PostgreSQL and a remotely hosted FreeLLMAPI gateway, and preserves the existing approved visual design with zero UI changes.

### User Review & Critical Decisions

> [!IMPORTANT]
> The existing frontend visual design, layout, styling, components, and user interaction flows are strictly locked and will not be modified. All changes are scoped to backend configuration, AI gateway resilience, unified container packaging, cloud database connectivity, tests, and deployment documentation.

- **Confirmed Decision 1 — Remote FreeLLMAPI Gateway with Optional Failover**: Production uses the user's `FREELLM_API_KEY` against a remotely hosted FreeLLMAPI gateway (deployed as a dedicated cloud container/service or remote OpenAI-compatible `/v1` endpoint). In `production`, local addresses (`localhost`, `127.0.0.1`, `host.docker.internal`) are explicitly rejected by startup validation so production can never accidentally depend on the developer's computer.
- **Confirmed Decision 2 — Unified Container Serving Built SPA + API + Cloud PostgreSQL**: In production, a single multi-stage Docker container builds both the React SPA and the Express backend, enables reverse-proxy support (`trust proxy`) for secure session cookies over HTTPS, serves the compiled SPA alongside `/api/v1/*` and `/health`, and connects to managed Cloud PostgreSQL via `DATABASE_URL` / `DB_URL` (with optional TLS/SSL) and automatic startup schema migration.

### 1. Overview & Core Concept

- **What It Does**: Transforms `ARS_LLM` from a local-desktop-dependent prototype into a self-contained cloud-deployable corporate AI workspace where the frontend, backend API, PostgreSQL persistence, session authentication, quota enforcement, and FreeLLMAPI model routing operate entirely on remote infrastructure.
- **Target Audience / Persona**: Corporate employees using the chat workspace and system administrators managing users, quotas, and cloud deployments.
- **Key Value**: Eliminates single-point-of-failure dependency on the developer's workstation while maintaining full compatibility with FreeLLMAPI keys, SSE token streaming, corporate system prompt injection, and PostgreSQL quota accounting.

### 2. User Experience & Visual Design

- **Key User Flows**:
  - **Zero-Change Visual & Interactive Experience**: Users log in via session-backed authentication, browse and search conversations in the collapsible sidebar, stream AI responses via SSE, export threads to Markdown, use Text-to-Speech playback, and manage user quotas in the Admin panel with zero visual or behavioral changes.
  - **Same-Origin Production Serving**: When deployed as a unified container, the browser loads the React application and communicates with `/api/v1/*` on the same origin over HTTPS, eliminating cross-origin cookie issues and local proxy dependencies.
- **Visual Identity & Theme**:
  - *Aesthetic Direction*: Strictly preserves the existing approved corporate dashboard design (100% locked).
  - *Color Palette & Mood*: Unchanged light and dark theme palettes using existing `--background`, `--primary`, `--accent`, and slate/indigo surface tokens.
  - *Typography & Hierarchy*: Unchanged font pairings, message bubble proportions, and WCAG-compliant contrast ratios.
  - *Component Styling & Layout*: Zero modifications to layout, spacing, sizing, borders, shadows, animations, sidebar, chat thread view, composer, quick prompts, or modals.
- **Interactive Feedback & Motion**: Preserves existing SSE streaming indicators, quota status displays, and error notifications without alteration.

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Remote FreeLLMAPI Service Architecture & Production URL Guard**
  - *Chosen Approach*: Because FreeLLMAPI is a self-hosted OpenAI-compatible gateway that defaults to `127.0.0.1:31415` on desktop, production requires hosting the FreeLLMAPI gateway in the cloud (either as a companion container in the cloud environment or pointing `FREELLM_API_BASE_URL` to a remote OpenAI-compatible `/v1` endpoint) authenticated with `FREELLM_API_KEY`. Startup validation in `NODE_ENV=production` rejects `host.docker.internal`, `localhost`, and `127.0.0.1` for `FREELLM_API_BASE_URL`. In addition, the client service supports configurable request timeout, transient retry on network/502/503/504 errors, and an optional secondary fallback OpenAI-compatible endpoint (`FREELLM_FALLBACK_BASE_URL` / `FREELLM_FALLBACK_API_KEY` / `FREELLM_FALLBACK_MODEL`) for high availability.
  - *Why*: Guarantees that a production deployment fails fast if misconfigured with a developer-local address and stays resilient against upstream provider rate limits.
  - *Alternatives Considered*: Replacing FreeLLMAPI with a hardcoded single-vendor SDK was rejected because the user already has a `FREELLM_API_KEY` and relies on the OpenAI-compatible `/v1/chat/completions` contract.
- **Decision 2: Unified Production Container (SPA + API) & Reverse Proxy Readiness**
  - *Chosen Approach*: Configure Express to enable `trust proxy` in production (required for `cookie.secure: true` and accurate client IP rate-limiting behind cloud load balancers) and serve the built frontend static bundle with an SPA catch-all route for non-API paths.
  - *Why*: Simplifies deployment on Render, Railway, Fly.io, Google Cloud Run, or any Docker VPS to a single web service image + managed PostgreSQL, while keeping `connect.sid` cookies first-party (`SameSite=Lax`).
  - *Alternatives Considered*: Hosting frontend and backend on separate domains was passed over because cross-site session cookies require `SameSite=None; Secure` and extra CORS complexity.
- **Decision 3: Cloud PostgreSQL Connection String & TLS Support**
  - *Chosen Approach*: Support both standard cloud `DATABASE_URL` / `DB_URL` connection strings and discrete `POSTGRES_*` variables, with configurable TLS (`POSTGRES_SSL=true` / `POSTGRES_SSL_REJECT_UNAUTHORIZED`), and optional automatic SQL migration execution at startup (`AUTO_MIGRATE=true`).
  - *Why*: Managed PostgreSQL providers (Neon, Supabase, Render, Railway, Cloud SQL, RDS) typically inject a single `DATABASE_URL` and require SSL in production.

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                        Cloud Load Balancer / HTTPS Proxy                     │
└───────────────────────────────────────┬──────────────────────────────────────┘
                                        │ HTTPS (Same Origin)
                                        ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                 Unified Production Container (ARS_LLM Service)               │
│                                                                              │
│  ┌────────────────────────────────────┐  ┌────────────────────────────────┐  │
│  │   Static SPA Server (Express)      │  │   REST & SSE API (/api/v1/*)   │  │
│  │   • Serves compiled React bundle   │  │   • trust proxy enabled        │  │
│  │   • SPA fallback for UI routes     │  │   • Auth, Conversations, Admin │  │
│  │   • Preserves 100% of existing UI  │  │   • Quota & Instruction guard  │  │
│  └────────────────────────────────────┘  └───────┬────────────────┬───────┘  │
└──────────────────────────────────────────────────┼────────────────┼──────────┘
                                                   │                │
                         PostgreSQL Wire (TLS/SSL) │                │ HTTPS /v1/chat/completions
                                                   ▼                ▼ (Bearer FREELLM_API_KEY)
┌────────────────────────────────────────────────────┐  ┌──────────────────────────────────────┐
│            Managed Cloud PostgreSQL                │  │    Remote FreeLLMAPI Gateway /       │
│  • Users, Sessions, Conversations, Messages        │  │    Cloud OpenAI-Compatible Endpoint  │
│  • Atomic Quotas & Usage Events                    │  │  • Hosted independently in cloud     │
│  • Auto-migrated on container startup              │  │  • Optional Fallback Endpoint        │
└────────────────────────────────────────────────────┘  └──────────────────────────────────────┘
```

- **Data Model & State**:
  - Preserves all 5 PostgreSQL tables (`users`, `sessions`, `conversations`, `messages`, `quotas`, `usage_events`) and existing SQL migrations without breaking schema changes.
  - Extends runtime environment schema with cloud-ready settings:
    - `DATABASE_URL` / `DB_URL` and `POSTGRES_SSL` (`true` / `false`)
    - `TRUST_PROXY` (defaults to `true` in production)
    - `SERVE_STATIC_SPA` / `FRONTEND_DIST_PATH` (serves built React SPA when present)
    - `AUTO_MIGRATE` (runs idempotent SQL migrations before accepting traffic when enabled)
    - `FREELLM_API_BASE_URL` (strictly validated in production to reject `localhost`, `127.0.0.1`, `0.0.0.0`, and `host.docker.internal`)
    - Optional fallback settings (`FREELLM_FALLBACK_BASE_URL`, `FREELLM_FALLBACK_API_KEY`, `FREELLM_FALLBACK_MODEL`)
- **Interactive Component & State Mapping**:
  - **Startup Config Validator**: Rejects local-only `FREELLM_API_BASE_URL` and `POSTGRES_HOST` in `production`, accepts `DATABASE_URL` or `POSTGRES_*`, and verifies all required production secrets.
  - **Database Pool & Migration Runner**: Initializes `pg.Pool` with `connectionString` + SSL when configured, and exposes a reusable `runMigrations()` function callable both via CLI and automatically on production startup (`AUTO_MIGRATE=true`).
  - **FreeLLMAPI Client Service**: Streams and fetches completions from the remote `FREELLM_API_BASE_URL` using `FREELLM_API_KEY`, with automatic fallback to `FREELLM_FALLBACK_BASE_URL` if configured and the primary endpoint fails with a network error, 429, or 5xx status.
  - **Unified Express Server**: Mounts `/api/v1/*` and `/health`, and when the compiled frontend directory exists, serves static assets and falls back to `index.html` for client-side routes.
- **Verification & Audit Strategy**:
  - Execute frontend build, backend build, expanded unit tests (covering production `FREELLM_API_BASE_URL` local-host rejection, `DATABASE_URL` parsing, FreeLLMAPI remote streaming/fallback, and unified SPA serving), and `npm audit` dependency security audit, documenting all actual outputs and cloud deployment steps/costs in the Development Journal.

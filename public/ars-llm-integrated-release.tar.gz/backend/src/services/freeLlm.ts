import env from "../config/index.js";

export interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface FreeLlmProviderEndpoint {
  name: "primary" | "fallback";
  baseUrl: string;
  apiKey: string;
  model: string;
  timeoutMs: number;
}

export interface FreeLlmRuntimeConfig {
  FREELLM_API_BASE_URL: string;
  FREELLM_API_KEY: string;
  FREELLM_MODEL: string;
  FREELLM_TIMEOUT_MS?: number;
  FREELLM_FALLBACK_BASE_URL?: string;
  FREELLM_FALLBACK_API_KEY?: string;
  FREELLM_FALLBACK_MODEL?: string;
}

interface FreeLlmResponse {
  choices?: Array<{
    message?: {
      role?: string;
      content?: string;
    };
    finish_reason?: string | null;
  }>;
  error?: {
    message?: string;
  };
}

/**
 * Resolves the ordered list of configured AI provider endpoints (primary FreeLLMAPI
 * endpoint followed by optional fallback endpoint if configured).
 */
export function resolveProviderEndpoints(
  config: FreeLlmRuntimeConfig = env
): FreeLlmProviderEndpoint[] {
  const timeoutMs = config.FREELLM_TIMEOUT_MS ?? 120_000;
  const endpoints: FreeLlmProviderEndpoint[] = [];

  if (config.FREELLM_API_BASE_URL && config.FREELLM_API_KEY) {
    endpoints.push({
      name: "primary",
      baseUrl: config.FREELLM_API_BASE_URL.replace(/\/+$/, ""),
      apiKey: config.FREELLM_API_KEY,
      model: config.FREELLM_MODEL || "auto",
      timeoutMs,
    });
  }

  if (config.FREELLM_FALLBACK_BASE_URL && config.FREELLM_FALLBACK_API_KEY) {
    endpoints.push({
      name: "fallback",
      baseUrl: config.FREELLM_FALLBACK_BASE_URL.replace(/\/+$/, ""),
      apiKey: config.FREELLM_FALLBACK_API_KEY,
      model: config.FREELLM_FALLBACK_MODEL || config.FREELLM_MODEL || "auto",
      timeoutMs,
    });
  }

  return endpoints;
}

function isRetryableStatus(status: number): boolean {
  return status === 408 || status === 429 || status >= 500;
}

export async function chatWithFreeLlm(
  messages: ChatMessage[],
  config: FreeLlmRuntimeConfig = env,
  fetchFn: typeof fetch = fetch
): Promise<string> {
  const endpoints = resolveProviderEndpoints(config);
  if (endpoints.length === 0) {
    throw new Error("FreeLLMAPI is not configured");
  }

  let lastError: Error | null = null;

  for (let i = 0; i < endpoints.length; i++) {
    const ep = endpoints[i];
    const hasFallback = i < endpoints.length - 1;

    try {
      const response = await fetchFn(`${ep.baseUrl}/chat/completions`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${ep.apiKey}`,
        },
        body: JSON.stringify({
          model: ep.model,
          messages,
          stream: false,
        }),
        signal: AbortSignal.timeout(ep.timeoutMs),
      });

      const data = (await response.json().catch(() => null)) as
        | FreeLlmResponse
        | null;

      if (!response.ok) {
        console.error(
          `FreeLLMAPI (${ep.name}) request failed with HTTP ${response.status}`
        );

        const err = new Error(
          response.status === 401 || response.status === 403
            ? "FreeLLMAPI authentication failed"
            : `FreeLLMAPI returned HTTP ${response.status}`
        );

        if (hasFallback && isRetryableStatus(response.status)) {
          lastError = err;
          continue;
        }
        throw err;
      }

      const content = data?.choices?.[0]?.message?.content;

      if (typeof content !== "string" || !content.trim()) {
        const emptyErr = new Error("FreeLLMAPI returned an empty response");
        if (hasFallback) {
          lastError = emptyErr;
          continue;
        }
        throw emptyErr;
      }

      return content;
    } catch (err) {
      const normalizedErr =
        err instanceof Error ? err : new Error("FreeLLMAPI request failed");
      if (hasFallback && !normalizedErr.message.includes("authentication failed")) {
        lastError = normalizedErr;
        continue;
      }
      throw normalizedErr;
    }
  }

  throw lastError ?? new Error("FreeLLMAPI request failed");
}

export async function* streamChatWithFreeLlm(
  messages: ChatMessage[],
  signal?: AbortSignal,
  config: FreeLlmRuntimeConfig = env,
  fetchFn: typeof fetch = fetch
): AsyncGenerator<string> {
  const endpoints = resolveProviderEndpoints(config);
  if (endpoints.length === 0) {
    throw new Error("FreeLLMAPI is not configured");
  }

  let response: Response | null = null;
  let lastError: Error | null = null;

  for (let i = 0; i < endpoints.length; i++) {
    const ep = endpoints[i];
    const hasFallback = i < endpoints.length - 1;

    try {
      const candidateResponse = await fetchFn(`${ep.baseUrl}/chat/completions`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${ep.apiKey}`,
        },
        body: JSON.stringify({
          model: ep.model,
          messages,
          stream: true,
        }),
        signal: signal
          ? AbortSignal.any([signal, AbortSignal.timeout(ep.timeoutMs)])
          : AbortSignal.timeout(ep.timeoutMs),
      });

      if (!candidateResponse.ok) {
        console.error(
          `FreeLLMAPI (${ep.name}) streaming request failed with HTTP ${candidateResponse.status}`
        );

        const err = new Error(
          candidateResponse.status === 401 || candidateResponse.status === 403
            ? "FreeLLMAPI authentication failed"
            : `FreeLLMAPI returned HTTP ${candidateResponse.status}`
        );

        if (hasFallback && isRetryableStatus(candidateResponse.status)) {
          lastError = err;
          continue;
        }
        throw err;
      }

      if (!candidateResponse.body) {
        const emptyBodyErr = new Error("FreeLLMAPI returned an empty stream");
        if (hasFallback) {
          lastError = emptyBodyErr;
          continue;
        }
        throw emptyBodyErr;
      }

      response = candidateResponse;
      break;
    } catch (err) {
      if (signal?.aborted) {
        throw err;
      }
      const normalizedErr =
        err instanceof Error ? err : new Error("FreeLLMAPI streaming failed");
      if (hasFallback && !normalizedErr.message.includes("authentication failed")) {
        lastError = normalizedErr;
        continue;
      }
      throw normalizedErr;
    }
  }

  if (!response || !response.body) {
    throw lastError ?? new Error("FreeLLMAPI returned an empty stream");
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let streamFinished = false;

  try {
    while (true) {
      const { value, done } = await reader.read();

      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      buffer = buffer.replace(/\r\n/g, "\n");

      const events = buffer.split("\n\n");
      buffer = events.pop() ?? "";

      for (const event of events) {
        for (const line of event.split("\n")) {
          if (!line.startsWith("data:")) continue;

          const data = line.slice(5).trim();

          if (!data) continue;

          if (data === "[DONE]") {
            streamFinished = true;
            return;
          }

          let parsed: {
            choices?: Array<{
              delta?: { content?: unknown };
            }>;
            error?: { message?: string };
          };

          try {
            parsed = JSON.parse(data);
          } catch {
            continue;
          }

          if (parsed.error) {
            throw new Error(
              parsed.error.message || "FreeLLMAPI streaming error"
            );
          }

          const content = parsed.choices?.[0]?.delta?.content;

          if (typeof content === "string" && content.length > 0) {
            yield content;
          }
        }
      }
    }

    // Process a final event if the server closed without a trailing separator.
    buffer += decoder.decode();

    if (!streamFinished && buffer.trim()) {
      for (const line of buffer.split("\n")) {
        if (!line.startsWith("data:")) continue;

        const data = line.slice(5).trim();

        if (!data || data === "[DONE]") continue;

        try {
          const parsed = JSON.parse(data);
          const content = parsed.choices?.[0]?.delta?.content;

          if (typeof content === "string" && content.length > 0) {
            yield content;
          }
        } catch {
          // Ignore an incomplete final event.
        }
      }
    }
  } finally {
    reader.releaseLock();
  }
}


import React, { useCallback, useState } from 'react';
import Icon from '../icon';
import ArsLogo from '../ArsLogo';
import './index.css';
import { useConversations } from '../../contexts/auth';

interface SidebarProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onRename: (id: number, newTitle: string) => Promise<void>;
  onDelete: (id: number) => Promise<void>;
  collapsed?: boolean;
  onToggleCollapse?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  searchQuery,
  onSearchChange,
  onRename,
  onDelete,
  collapsed = false,
  onToggleCollapse,
}) => {
  const {
    conversations,
    selectedConversationId,
    setSelectedConversationId,
    loading,
    error,
  } = useConversations();
  const [contextMenu, setContextMenu] = useState<{
    id: number;
    x: number;
    y: number;
  } | null>(null);

  const handleSelectConversation = useCallback(
    (id: number) => {
      setSelectedConversationId(id);
      setContextMenu(null);
    },
    [setSelectedConversationId]
  );

  const handleContextMenu = useCallback((e: React.MouseEvent, id: number) => {
    e.preventDefault();
    setContextMenu({
      id,
      x: e.clientX,
      y: e.clientY,
    });
  }, []);

  const handleCloseContextMenu = useCallback(() => {
    setContextMenu(null);
  }, []);

  const handleRename = useCallback(
    async (id: number, newTitle: string) => {
      await onRename(id, newTitle);
      setContextMenu(null);
    },
    [onRename]
  );

  const handleDelete = useCallback(
    async (id: number) => {
      await onDelete(id);
      setContextMenu(null);
    },
    [onDelete]
  );

  const filteredConversations = conversations.filter((conv) =>
    conv.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <aside
      className={`sidebar ${collapsed ? 'collapsed' : ''}`}
      style={{ width: collapsed ? 'var(--sidebar-width-collapsed)' : 'var(--sidebar-width)' }}
    >
      <div className="brand">
        <div className="logo">
          <ArsLogo collapsed={collapsed} />
        </div>
        {!collapsed && (
          <div className="brand-copy">
            <div className="muted">Корпоративный AI-ассистент</div>
          </div>
        )}
        {onToggleCollapse && (
          <button
            type="button"
            onClick={onToggleCollapse}
            aria-label={collapsed ? 'Развернуть боковую панель' : 'Свернуть боковую панель'}
            title={collapsed ? 'Развернуть панель' : 'Свернуть панель'}
            className="collapse-toggle flex items-center justify-center w-7 h-7 rounded-lg border border-[color:var(--color-border-default)] bg-[color:var(--color-surface-1)] text-[color:var(--color-text-secondary)] hover:bg-[color:var(--color-surface-2)] transition-colors shrink-0"
          >
            <Icon name={collapsed ? 'chevronRight' : 'chevronLeft'} size={16} />
          </button>
        )}
      </div>

      <div className="search">
        <Icon name="search" size={16} className="mr-2" />
        {!collapsed ? (
          <input
            type="text"
            placeholder="Поиск чатов..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="search-input"
          />
        ) : (
          <button
            type="button"
            onClick={() => onSearchChange(searchQuery)}
            aria-label="Поиск (Ctrl + K)"
            className="focus-ring flex items-center justify-center w-full h-10 rounded-xl border border-[color:var(--color-border-default)] bg-[color:var(--color-surface-1)] text-[color:var(--color-text-muted)] hover:border-[color:var(--color-accent-primary)]"
          >
            <Icon name="search" size={16} />
          </button>
        )}
        {!collapsed && <span className="float-right">Ctrl K</span>}
      </div>

      {!collapsed && <div className="section-label">РАБОЧАЯ ОБЛАСТЬ</div>}
      <nav className="nav active">
        <Icon name="message" size={16} className="mr-2" />
        {!collapsed && <span>Чаты</span>}
      </nav>
      <nav className="nav">
        <Icon name="folder" size={16} className="mr-2" />
        {!collapsed && <span>Проекты</span>}
      </nav>
      <nav className="nav">
        <Icon name="book" size={16} className="mr-2" />
        {!collapsed && <span>Библиотека промптов</span>}
      </nav>
      <nav className="nav">
        <Icon name="history" size={16} className="mr-2" />
        {!collapsed && <span>История</span>}
      </nav>

      <div className="chatlist">
        {!collapsed && <div className="section-label">ПОСЛЕДНИЕ ЧАТЫ</div>}

        {loading && (
          <span className="text-xs text-[color:var(--color-text-muted)]">Загрузка...</span>
        )}

        {error && (
          <span className="text-xs text-[color:var(--color-text-muted)] mb-2">Ошибка: {error}</span>
        )}

        {filteredConversations.length === 0 ? (
          <div className="text-center py-8 text-[color:var(--color-text-muted)]">
            {!collapsed && <span>Создайте первый чат</span>}
          </div>
        ) : (
          filteredConversations.map((conv) => (
            <nav
              key={conv.id}
              className={`nav ${selectedConversationId === conv.id ? 'active' : ''}`}
              onClick={() => handleSelectConversation(conv.id)}
              onContextMenu={(e) => handleContextMenu(e, conv.id)}
              title={collapsed ? conv.title : ''}
            >
              <Icon name="message" size={16} className="mr-2" />
              {!collapsed && (
                <span className="sidebar-item-text line-clamp-2 w-0">{conv.title}</span>
              )}
            </nav>
          ))
        )}
      </div>

      {contextMenu && (
        <div
          className="context-menu"
          style={{ top: contextMenu.y, left: contextMenu.x }}
          onClick={handleCloseContextMenu}
        >
          <button
            className="context-menu-item"
            onClick={(e) => {
              e.stopPropagation();
              const newTitle = prompt('Введите новое название чата:',
                conversations.find((c) => c.id === contextMenu.id)?.title || ''
              );
              if (newTitle) {
                handleRename(contextMenu.id, newTitle);
              }
            }}
          >
            Переименовать
          </button>
          <button
            className="context-menu-item"
            onClick={(e) => {
              e.stopPropagation();
              if (window.confirm('Удалить чат?')) {
                handleDelete(contextMenu.id);
              }
            }}
          >
            Удалить
          </button>
        </div>
      )}

      {!collapsed && (
        <div className="bottom">
          <nav className="nav">
            <Icon name="help" size={16} className="mr-2" />
            <span>Помощь и поддержка</span>
          </nav>
          <div className="profile">
            <div className="avatar">С</div>
            <div className="profile-copy">
              <b>Сотрудник</b>
              <div className="muted">employee@company.kz</div>
            </div>
          </div>
        </div>
      )}
    </aside>
  );
};

export default Sidebar;
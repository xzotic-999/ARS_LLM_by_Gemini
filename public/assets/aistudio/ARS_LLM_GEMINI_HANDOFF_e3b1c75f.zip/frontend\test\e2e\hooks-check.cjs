const puppeteer = require('puppeteer-core');
const CHROME = 'C:/Program Files/Google/Chrome/Application/chrome.exe';

(async () => {
  const browser = await puppeteer.launch({
    executablePath: CHROME,
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
  });
  const page = await browser.newPage();
  const consoleErrors = [];
  const pageErrors = [];
  const warnings = [];

  page.on('console', (msg) => {
    const type = msg.type();
    const text = msg.text();
    if (type === 'error') consoleErrors.push(text);
    if (type === 'warning') warnings.push(text);
  });
  page.on('pageerror', (err) => pageErrors.push(String(err)));
  page.on('requestfailed', (req) => consoleErrors.push(`REQFAIL ${req.url()} ${req.failure()?.errorText}`));

  await page.goto('http://localhost:5173', { waitUntil: 'networkidle0', timeout: 30000 });
  await new Promise((r) => setTimeout(r, 2000));

  const loginVisible = await page.evaluate(() => !!document.querySelector('input[id="login-email"]'));

  const meResp = await page.evaluate(async () => {
    const r = await fetch('/api/v1/auth/me', { credentials: 'include' });
    return { status: r.status, body: await r.text().then(t => t.slice(0, 300)) };
  });

  console.log(JSON.stringify({
    phase: 'unauth',
    loginVisible,
    meResp,
    consoleErrors,
    pageErrors,
    warnings,
  }, null, 2));
  await browser.close();
  process.exit(0);
})();

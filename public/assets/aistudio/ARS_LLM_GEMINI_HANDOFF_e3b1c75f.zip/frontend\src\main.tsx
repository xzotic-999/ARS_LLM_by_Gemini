import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import { AuthProvider, ConversationsProvider } from "./contexts/auth";
import { ThemeProvider } from "./lib/theme.tsx";
import "./styles/globals.css";

const container = document.getElementById("root");

if (!container) {
  throw new Error('Root element "#root" not found');
}

const root = createRoot(container);

root.render(
  <React.StrictMode>
    <AuthProvider>
      <ConversationsProvider>
        <ThemeProvider>
          <App />
        </ThemeProvider>
      </ConversationsProvider>
    </AuthProvider>
  </React.StrictMode>
);

import React from 'react';
import {
  Image as ImageIcon,
  Code2,
  FileText,
  ListTodo,
  Lightbulb,
} from 'lucide-react';

export type QuickPromptIconType = 'image' | 'code' | 'summarize' | 'plan' | 'idea';

export interface QuickPrompt {
  id: string;
  label: string;
  iconType: QuickPromptIconType;
  promptText: string;
}

interface QuickPromptsProps {
  prompts: QuickPrompt[];
  onSelectQuickPrompt: (prompt: QuickPrompt) => void;
}

export const QuickPrompts: React.FC<QuickPromptsProps> = ({
  prompts,
  onSelectQuickPrompt,
}) => {
  const renderIconBadge = (iconType: QuickPromptIconType) => {
    switch (iconType) {
      case 'image':
        return (
          <span
            className="w-7 h-7 rounded-lg bg-[#FFF3E6] dark:bg-orange-500/20 text-[#F97316] dark:text-orange-400 flex items-center justify-center shrink-0"
            aria-hidden="true"
          >
            <ImageIcon className="w-4 h-4 stroke-[2]" />
          </span>
        );
      case 'code':
        return (
          <span
            className="w-7 h-7 rounded-lg bg-[#EEF0FF] dark:bg-indigo-500/20 text-[#4F46E5] dark:text-indigo-400 flex items-center justify-center shrink-0"
            aria-hidden="true"
          >
            <Code2 className="w-4 h-4 stroke-[2]" />
          </span>
        );
      case 'summarize':
        return (
          <span
            className="w-7 h-7 rounded-lg bg-[#E8F8EE] dark:bg-emerald-500/20 text-[#22C55E] dark:text-emerald-400 flex items-center justify-center shrink-0"
            aria-hidden="true"
          >
            <FileText className="w-4 h-4 stroke-[2]" />
          </span>
        );
      case 'plan':
        return (
          <span
            className="w-7 h-7 rounded-lg bg-[#FFF4E5] dark:bg-amber-500/20 text-[#F59E0B] dark:text-amber-400 flex items-center justify-center shrink-0"
            aria-hidden="true"
          >
            <ListTodo className="w-4 h-4 stroke-[2]" />
          </span>
        );
      case 'idea':
        return (
          <span
            className="w-7 h-7 rounded-lg bg-[#F1EEFF] dark:bg-violet-500/20 text-[#6366F1] dark:text-violet-400 flex items-center justify-center shrink-0"
            aria-hidden="true"
          >
            <Lightbulb className="w-4 h-4 stroke-[2]" />
          </span>
        );
    }
  };

  const firstRow = prompts.slice(0, 3);
  const secondRow = prompts.slice(3, 5);

  return (
    <section aria-labelledby="quick-prompts-heading" className="w-full max-w-[740px] mx-auto mt-8">
      <h3
        id="quick-prompts-heading"
        className="text-[14.5px] font-bold text-[color:var(--color-text-primary)] dark:text-slate-100 text-center mb-4"
      >
        Выберите быстрый запрос
      </h3>

      {/* Top Row (3 items on desktop) */}
      <div className="flex flex-wrap items-center justify-center gap-3">
        {firstRow.map((qp) => (
          <button
            key={qp.id}
            type="button"
            onClick={() => onSelectQuickPrompt(qp)}
            className="focus-ring group h-[44px] pl-2.5 pr-4 rounded-full border border-[color:var(--color-border-default)] bg-[color:var(--color-surface-1)] hover:border-[color:var(--color-accent-primary)] dark:hover:border-indigo-500/70 hover:shadow-xs flex items-center gap-2.5 text-[13.5px] font-medium text-[color:var(--color-text-primary)] dark:text-slate-100 transition-all whitespace-nowrap"
          >
            {renderIconBadge(qp.iconType)}
            <span>{qp.label}</span>
          </button>
        ))}
      </div>

      {/* Bottom Row (2 items centered on desktop) */}
      <div className="flex flex-wrap items-center justify-center gap-3 mt-3">
        {secondRow.map((qp) => (
          <button
            key={qp.id}
            type="button"
            onClick={() => onSelectQuickPrompt(qp)}
            className="focus-ring group h-[44px] pl-2.5 pr-4 rounded-full border border-[color:var(--color-border-default)] bg-[color:var(--color-surface-1)] hover:border-[color:var(--color-accent-primary)] dark:hover:border-indigo-500/70 hover:shadow-xs flex items-center gap-2.5 text-[13.5px] font-medium text-[color:var(--color-text-primary)] dark:text-slate-100 transition-all whitespace-nowrap"
          >
            {renderIconBadge(qp.iconType)}
            <span>{qp.label}</span>
          </button>
        ))}
      </div>
    </section>
  );
};

export default QuickPrompts;
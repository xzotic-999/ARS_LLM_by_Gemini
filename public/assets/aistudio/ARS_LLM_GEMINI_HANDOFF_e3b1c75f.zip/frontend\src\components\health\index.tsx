import React, { useState, useEffect } from 'react';
import { Icon } from '../icon';
import './index.css';

interface HealthIndicatorProps {
  checkUrl?: string;
  intervalMs?: number;
}

const API_BASE = (import.meta.env.VITE_API_BASE_URL as string) || '';

export const HealthIndicator: React.FC<HealthIndicatorProps> = ({
  checkUrl = `${API_BASE}/health`,
  intervalMs = 30000,
}) => {
  const [status, setStatus] = useState<'checking' | 'online' | 'offline'>('checking');

  const checkHealth = async () => {
    try {
      const res = await fetch(checkUrl, { method: 'GET' });
      setStatus(res.ok ? 'online' : 'offline');
    } catch {
      setStatus('offline');
    }
  };

  useEffect(() => {
    checkHealth();
    const interval = setInterval(checkHealth, intervalMs);
    return () => clearInterval(interval);
  }, [checkUrl, intervalMs]);

  const config = {
    checking: {
      color: 'text-text-muted',
      icon: 'healthOff',
      label: 'Проверка',
    },
    online: {
      color: 'text-success',
      icon: 'health',
      label: 'Онлайн',
    },
    offline: {
      color: 'text-error',
      icon: 'error',
      label: 'Офлайн',
    },
  };

  const { color, icon, label } = config[status];

  return (
    <div className="health-indicator flex items-center gap-2 text-sm">
      <Icon name={icon} size={12} className={color} />
      <span className={`text-xs ${color}`}>{label}</span>
    </div>
  );
};

export default HealthIndicator;

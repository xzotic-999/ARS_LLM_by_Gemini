import React, { useState, useRef, useEffect } from 'react';
import { Icon } from '../icon';
import './index.css';

interface MessageInputProps {
  onSend: (content: string) => void;
  disabled?: boolean;
}

export const MessageInput: React.FC<MessageInputProps> = ({
  onSend,
  disabled,
}) => {
  const [value, setValue] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const autoGrow = () => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 200) + 'px';
  };

  useEffect(() => {
    autoGrow();
  }, [value]);

  const handleSend = () => {
    const trimmed = value.trim();
    if (!trimmed) return;
    onSend(trimmed);
    setValue('');
    autoGrow();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="message-input-container flex items-end gap-2 px-3 py-3 bg-surface-1 border-t border-border-subtle">
      <div className="flex-1">
        <textarea
          ref={textareaRef}
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Напишите сообщение..."
          rows={1}
          disabled={disabled}
          className="message-input w-full resize-none overflow-hidden bg-surface-3 border border-border-default rounded-lg px-4 py-3 text-base text-text-primary placeholder-text-muted focus:outline-none focus:border-accent focus:shadow-[0_0_0_3px_var(--color-accent-primary-subtle)] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          style={{ minHeight: '48px', maxHeight: '200px' }}
        />
      </div>
      <button
        onClick={handleSend}
        disabled={disabled || !value.trim()}
        className="send-btn flex items-center justify-center w-12 h-12 rounded-lg bg-accent text-surface-0 hover:bg-accent-hover transition-colors disabled:opacity-40 disabled:cursor-not-allowed flex-shrink-0"
        aria-label="Отправить сообщение"
      >
        <Icon name="send" size={20} />
      </button>
    </div>
  );
};

export default MessageInput;
// Minimal React Error Boundary + diagnostic event collector.
// Never logs passwords, tokens, cookies, headers, or message bodies.

export interface DiagnosticEvent {
  id: string;
  ts: number;
  type: 'error' | 'warning' | 'api' | 'navigation' | 'auth';
  severity: 'low' | 'medium' | 'high';
  message: string;
  context?: Record<string, unknown>;
  stack?: string;
}

const MAX_EVENTS = 100;
const events: DiagnosticEvent[] = [];

function correlationId(): string {
  return 'corr_' + Math.random().toString(36).slice(2, 10);
}

export const diag = {
  push(event: Omit<DiagnosticEvent, 'id' | 'ts'>): DiagnosticEvent {
    const full: DiagnosticEvent = {
      id: correlationId(),
      ts: Date.now(),
      ...event,
    };
    events.push(full);
    if (events.length > MAX_EVENTS) events.shift();
    return full;
  },

  list(): DiagnosticEvent[] {
    return [...events];
  },

  clear(): void {
    events.length = 0;
  },

  // Sanitize arbitrary objects so secrets can never leak.
  sanitize(obj: unknown): unknown {
    if (obj === null || typeof obj !== 'object') return obj;
    if (Array.isArray(obj)) return obj.map((v) => diag.sanitize(v));
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(obj as Record<string, unknown>)) {
      const key = k.toLowerCase();
      if (/password|token|cookie|secret|authorization|api_key|apikey|session/.test(key)) {
        out[k] = '[REDACTED]';
      } else {
        out[k] = diag.sanitize(v);
      }
    }
    return out;
  },
};

// Capture uncaught errors and unhandled promise rejections globally.
if (typeof window !== 'undefined') {
  window.addEventListener('error', (event: ErrorEvent) => {
    diag.push({
      type: 'error',
      severity: 'high',
      message: event.message || 'Uncaught error',
      stack: event.error?.stack,
      context: { filename: event.filename, lineno: event.lineno, colno: event.colno },
    });
  });

  window.addEventListener('unhandledrejection', (event: PromiseRejectionEvent) => {
    const reason = event.reason as Error | undefined;
    diag.push({
      type: 'error',
      severity: 'high',
      message: reason?.message || 'Unhandled promise rejection',
      stack: reason?.stack,
    });
  });
}

export default diag;
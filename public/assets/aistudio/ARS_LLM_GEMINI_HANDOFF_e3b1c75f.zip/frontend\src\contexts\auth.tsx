import React, { createContext, useCallback, useContext, useEffect, useState } from "react";
import { conversationsApi, messagesApi, Conversation, ConversationMessage } from "../services/conversations";

export interface AuthUser {
  id: number;
  name: string;
  email: string;
  role: "admin" | "employee";
  is_active: boolean;
  email_verified: boolean;
  created_at: string | null;
}

interface AuthContextType {
  user: AuthUser | null;
  loading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  refresh: () => Promise<void>;
  clearError: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

interface ConversationsContextType {
  conversations: Conversation[];
  messages: ConversationMessage[];
  selectedConversationId: number | null;
  setSelectedConversationId: (id: number | null) => void;
  loading: boolean;
  error: string | null;
  createConversation: (title: string) => Promise<Conversation | null>;
  updateConversation: (id: number, title: string) => Promise<boolean>;
  deleteConversation: (id: number) => Promise<boolean>;
  sendMessage: (
    conversationId: number,
    role: 'user' | 'assistant' | 'system',
    text: string,
    userId?: number
  ) => Promise<ConversationMessage | null>;
}

const ConversationsContext = createContext<ConversationsContextType | null>(null);

export function useConversations(): ConversationsContextType {
  const ctx = useContext(ConversationsContext);
  if (!ctx) {
    throw new Error("useConversations must be used within a ConversationsProvider");
  }
  return ctx;
}

export const ConversationsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const userId = user?.id;

  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [messages, setMessages] = useState<ConversationMessage[]>([]);
  const [selectedConversationId, setSelectedConversationId] = useState<number | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const loadConversations = useCallback(async () => {
    if (userId === undefined) return;
    setLoading(true);
    setError(null);
    try {
      const data = await conversationsApi.list(userId as number);
      setConversations(data);
      if (data.length > 0 && selectedConversationId === null) {
        setSelectedConversationId(data[0].id);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  }, [userId]);

  const loadMessages = useCallback(async (conversationId: number) => {
    if (userId == null) return;
    setLoading(true);
    setError(null);
    try {
      const data = await messagesApi.list(conversationId);
      if (selectedConversationId === conversationId) {
        setMessages(data);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  }, [userId, selectedConversationId]);

    // Load conversations whenever the authenticated user changes.
  useEffect(() => {
    if (userId == null) {
      setConversations([]);
      setSelectedConversationId(null);
      setMessages([]);
      setError(null);
      setLoading(false);
      return;
    }

    void loadConversations();
  }, [userId, loadConversations]);

  // Load messages for the selected conversation.
  useEffect(() => {
    if (selectedConversationId !== null) {
      loadMessages(selectedConversationId);
    } else {
      setMessages([]);
    }
  }, [selectedConversationId, loadMessages]);

  const createConversation = useCallback(
    async (title: string): Promise<Conversation | null> => {
      setLoading(true);
      setError(null);
      try {
        const newConv = await conversationsApi.create(title);
        setConversations((prev) => [newConv, ...prev]);
        setSelectedConversationId(newConv.id);
        return newConv;
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Unknown error');
        return null;
      } finally {
        setLoading(false);
      }
    },
    []
  );

  const updateConversation = useCallback(
    async (id: number, title: string): Promise<boolean> => {
      setLoading(true);
      setError(null);
      try {
        await conversationsApi.update(id, title);
        setConversations((prev) =>
          prev.map((conv) => (conv.id === id ? { ...conv, title } : conv))
        );
        return true;
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Unknown error');
        return false;
      } finally {
        setLoading(false);
      }
    },
    []
  );

  const deleteConversation = useCallback(
    async (id: number): Promise<boolean> => {
      setLoading(true);
      setError(null);
      try {
        await conversationsApi.delete(id);
        setConversations((prev) => {
          const filtered = prev.filter((conv) => conv.id !== id);
          if (selectedConversationId === id) {
            setSelectedConversationId(filtered.length > 0 ? filtered[0].id : null);
            setMessages([]);
          }
          return filtered;
        });
        return true;
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Unknown error');
        return false;
      } finally {
        setLoading(false);
      }
    },
    [selectedConversationId]
  );

  const sendMessage = useCallback(
    async (
      conversationId: number,
      role: 'user' | 'assistant' | 'system',
      text: string,
      userId?: number
    ): Promise<ConversationMessage | null> => {
      setLoading(true);
      setError(null);
      try {
        const newMsg = await messagesApi.create(
          conversationId,
          role,
          text,
          userId
        );
        setMessages((prev) => [...prev, newMsg]);
        return newMsg;
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Unknown error');
        return null;
      } finally {
        setLoading(false);
      }
    },
    []
  );

  return (
    <ConversationsContext.Provider
      value={{
        conversations,
        messages,
        selectedConversationId,
        setSelectedConversationId,
        loading,
        error,
        createConversation,
        updateConversation,
        deleteConversation,
        sendMessage,
      }}
    >
      {children}
    </ConversationsContext.Provider>
  );
};

export function useAuth(): AuthContextType {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return ctx;
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const clearError = useCallback(() => setError(null), []);

  const refresh = useCallback(async () => {
    try {
      const response = await fetch("/api/v1/auth/me", {
        credentials: "include",
      });
      if (response.ok) {
        const data = await response.json();
        setUser(data.user as AuthUser);
      } else {
        setUser(null);
      }
    } catch {
      setUser(null);
    }
  }, []);

  const login = useCallback(
    async (email: string, password: string) => {
      setError(null);
      try {
        const response = await fetch("/api/v1/auth/login", {
          method: "POST",
          credentials: "include",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email, password }),
        });

        if (!response.ok) {
          const data = await response.json().catch(() => null);
          throw new Error(
            (data as { error?: { message?: string } } | null)?.error?.message ||
              "Login failed."
          );
        }

        const data = await response.json();
        setUser(data.user as AuthUser);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Login failed.");
        throw err;
      }
    },
    []
  );

  const logout = useCallback(async () => {
    setError(null);
    try {
      await fetch("/api/v1/auth/logout", {
        method: "POST",
        credentials: "include",
      });
    } finally {
      setUser(null);
    }
  }, []);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        await refresh();
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [refresh]);

  return (
    <AuthContext.Provider value={{ user, loading, error, login, logout, refresh, clearError }}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthProvider;
import React from "react";
import LoginPanel from "./LoginPanel";

export const LoginPage: React.FC = () => {
  return (
    <LoginPanel />
  );
};

export default LoginPage;
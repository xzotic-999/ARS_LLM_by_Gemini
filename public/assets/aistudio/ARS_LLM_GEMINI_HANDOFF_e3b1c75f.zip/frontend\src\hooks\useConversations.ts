import { useState, useEffect, useCallback } from 'react';
import { conversationsApi, messagesApi, Conversation, ConversationMessage } from '../services/conversations';

export const useConversations = (userId: number | null) => {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [messages, setMessages] = useState<ConversationMessage[]>([]);
  const [selectedConversationId, setSelectedConversationId] = useState<number | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Initialize state on mount
  useEffect(() => {
    if (userId === null) {
      setConversations([]);
      setSelectedConversationId(null);
      setMessages([]);
      return;
    }
    loadConversations();
  }, [userId]);

  // Fetch conversations for the user
  const loadConversations = useCallback(async () => {
    if (userId === null) return;
    setLoading(true);
    setError(null);
    try {
      const data = await conversationsApi.list(userId);
      setConversations(data);
      // Auto-select the most recent conversation if none selected
      if (data.length > 0 && selectedConversationId === null) {
        setSelectedConversationId(data[0].id);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  }, [userId]);

  // Load messages for the selected conversation
  const loadMessages = useCallback(async (conversationId: number) => {
    if (userId === null) return;
    setLoading(true);
    setError(null);
    try {
      const data = await messagesApi.list(conversationId);
      // Guard against race conditions: only apply the result if this is still
      // the selected conversation when the request completes.
      if (selectedConversationId === conversationId) {
        setMessages(data);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  }, [userId, selectedConversationId]);

  // Create a new conversation
  const createConversation = useCallback(
    async (title: string): Promise<Conversation | null> => {
      if (userId === null) return null;
      setLoading(true);
      setError(null);
      try {
        const newConv = await conversationsApi.create(title, userId);
        setConversations((prev) => [newConv, ...prev]);
        setSelectedConversationId(newConv.id);
        return newConv;
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Unknown error');
        return null;
      } finally {
        setLoading(false);
      }
    },
    [userId]
  );

  // Update conversation title
  const updateConversation = useCallback(
    async (id: number, title: string): Promise<boolean> => {
      setLoading(true);
      setError(null);
      try {
        await conversationsApi.update(id, title);
        setConversations((prev) =>
          prev.map((conv) => (conv.id === id ? { ...conv, title } : conv))
        );
        return true;
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Unknown error');
        return false;
      } finally {
        setLoading(false);
      }
    },
    []
  );

  // Delete a conversation
  const deleteConversation = useCallback(
    async (id: number): Promise<boolean> => {
      setLoading(true);
      setError(null);
      try {
        await conversationsApi.delete(id);
        setConversations((prev) => prev.filter((conv) => conv.id !== id));
        // If we deleted the selected conversation, select another or null
        if (selectedConversationId === id) {
          const remaining = conversations.filter((c) => c.id !== id);
          setSelectedConversationId(
            remaining.length > 0 ? remaining[0].id : null
          );
          setMessages([]);
        }
        return true;
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Unknown error');
        return false;
      } finally {
        setLoading(false);
      }
    },
    [conversations, selectedConversationId]
  );

  // Send a message (user or assistant)
  const sendMessage = useCallback(
    async (
      conversationId: number,
      role: 'user' | 'assistant' | 'system',
      text: string,
      userId?: number
    ): Promise<ConversationMessage | null> => {
      setLoading(true);
      setError(null);
      try {
        const newMsg = await messagesApi.create(
          conversationId,
          role,
          text,
          userId ?? undefined
        );
        setMessages((prev) => [...prev, newMsg]);
        return newMsg;
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Unknown error');
        return null;
      } finally {
        setLoading(false);
      }
    },
    []
  );

  // Initialize on mount
  useEffect(() => {
    loadConversations();
  }, [userId, loadConversations]);

  // Watch for selected conversation changes
  useEffect(() => {
    if (selectedConversationId !== null) {
      loadMessages(selectedConversationId as number);
    } else {
      setMessages([]);
    }
  }, [selectedConversationId, loadMessages]);

  return {
    conversations,
    messages,
    selectedConversationId,
    setSelectedConversationId,
    loading,
    error,
    createConversation,
    updateConversation,
    deleteConversation,
    sendMessage,
  };
};
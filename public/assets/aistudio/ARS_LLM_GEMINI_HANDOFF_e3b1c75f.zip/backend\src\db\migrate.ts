
import dotenv from "dotenv";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
import { runner } from "node-pg-migrate";
import env from "../config/index.js";

const currentDir = dirname(fileURLToPath(import.meta.url));
const projectRoot = resolve(currentDir, "../../../");
dotenv.config({ path: resolve(projectRoot, ".env") });

// Use source SQL migrations, which are not copied by TypeScript.
const migrationsDir = resolve(projectRoot, "backend/src/migrations");

(async () => {
  try {
    const result = await runner({
      migrationsTable: "migrations",
      dir: migrationsDir,
      databaseUrl: env.DB_URL,
      direction: "up",
      log: console.log,
    });

    console.log("Migrations applied:", result.map((r) => r.name));
  } catch (err) {
    console.error("Migration error", err);
    process.exit(1);
  }
})();

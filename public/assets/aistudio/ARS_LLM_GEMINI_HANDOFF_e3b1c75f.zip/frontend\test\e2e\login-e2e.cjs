const puppeteer = require('puppeteer-core');
const CHROME = 'C:/Program Files/Google/Chrome/Application/chrome.exe';
const EMAIL = process.env.E2E_EMAIL;
const PASSWORD = process.env.E2E_PASSWORD;

(async () => {
  if (!EMAIL || !PASSWORD) {
    console.error('Set E2E_EMAIL and E2E_PASSWORD env vars');
    process.exit(2);
  }
  const browser = await puppeteer.launch({
    executablePath: CHROME,
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox'],
  });
  const page = await browser.newPage();
  const consoleErrors = [];
  const pageErrors = [];
  const warnings = [];

  page.on('console', (msg) => {
    const type = msg.type();
    const text = msg.text();
    if (type === 'error') consoleErrors.push(text);
    if (type === 'warning') warnings.push(text);
  });
  page.on('pageerror', (err) => pageErrors.push(String(err)));
  page.on('requestfailed', (req) => consoleErrors.push(`REQFAIL ${req.url()} ${req.failure()?.errorText}`));

  const result = {};

  await page.goto('http://localhost:5173', { waitUntil: 'networkidle0', timeout: 30000 });
  await new Promise((r) => setTimeout(r, 2000));
  result.loginVisible = await page.evaluate(() => !!document.querySelector('input[id="login-email"]'));

  await page.type('input[id="login-email"]', EMAIL);
  await page.type('input[id="login-password"]', PASSWORD);
  await page.click('button[type="submit"]');
  await page.waitForNetworkIdle({ idleTime: 500, timeout: 20000 }).catch(() => null);
  await new Promise((r) => setTimeout(r, 2000));

  result.chatVisible = await page.evaluate(() => !!document.querySelector('.flex.h-screen'));
  result.sidebarVisible = await page.evaluate(() => !!document.querySelector('aside'));
  result.userNameText = await page.evaluate(() => {
    const btns = Array.from(document.querySelectorAll('button'));
    const b = btns.find((x) => /выйти|logout|sign out/i.test(x.textContent || ''));
    return b ? b.textContent?.slice(0, 60) : null;
  });

  result.meResp = await page.evaluate(async () => {
    const r = await fetch('/api/v1/auth/me', { credentials: 'include' });
    return { status: r.status, body: await r.text().then(t => t.slice(0, 300)) };
  });

  const logoutBtn = await page.evaluate(() => {
    const btns = Array.from(document.querySelectorAll('button'));
    const b = btns.find((x) => /выйти|logout|sign out/i.test(x.textContent || ''));
    return !!b;
  });
  result.logoutBtnFound = logoutBtn;
  if (logoutBtn) {
    await page.evaluate(() => {
      const btns = Array.from(document.querySelectorAll('button'));
      const b = btns.find((x) => /выйти|logout|sign out/i.test(x.textContent || ''));
      if (b) b.click();
    });
    await new Promise((r) => setTimeout(r, 2000));
    result.afterLogoutLoginVisible = await page.evaluate(() => !!document.querySelector('input[id="login-email"]'));
  }

  result.consoleErrors = [...consoleErrors];
  result.pageErrors = [...pageErrors];
  result.warnings = [...warnings];

  console.log(JSON.stringify(result, null, 2));
  await browser.close();
  process.exit(0);
})();

import React from 'react';
import Icon from './icon';
import { useAuth } from '../contexts/auth';
import { useTheme } from '../lib/theme.tsx';

interface TopBarProps {
  onNewChatClick?: () => void;
  onSettingsClick?: () => void;
  user: {
    id: number;
    name: string;
    email: string;
    role: "admin" | "employee";
    is_active: boolean;
    email_verified: boolean;
    created_at: string | null;
  };
  chatTitle: string;
}

export const TopBar: React.FC<TopBarProps> = ({ onNewChatClick, onSettingsClick, user, chatTitle }) => {
  const { logout } = useAuth();
  const { theme, toggleTheme } = useTheme();

  return (
    <header className="topbar">
      <div className="topbar-title">
        <span>{chatTitle}</span>
        <span className="muted"> / ARS LLM</span>
      </div>
      <div className="flex items-center gap-2">
        <button
          onClick={toggleTheme}
          className="secondary px-3 py-1.5 rounded-md border border-[color:var(--color-border-default)] bg-white text-[color:var(--color-text-secondary)] hover:bg-[color:var(--color-surface-2)] transition-colors text-sm"
          aria-label={theme === 'light' ? 'Тёмная тема' : 'Светлая тема'}
        >
          <Icon name={theme === 'light' ? 'moon' : 'sun'} size={16} />
          <span className="ml-1">{theme === 'light' ? 'Тёмная тема' : 'Светлая тема'}</span>
        </button>

        <button
          onClick={onSettingsClick}
          className="secondary p-2.5 rounded-md border border-[color:var(--color-border-default)] bg-white text-[color:var(--color-text-secondary)] hover:bg-[color:var(--color-surface-2)] transition-colors"
          aria-label="Настройки"
        >
          <Icon name="settings" size={18} />
        </button>

        <button
          onClick={onNewChatClick}
          className="primary px-4 py-2 rounded-md text-sm font-semibold"
          aria-label="Новый чат"
        >
          <Icon name="plus" size={16} className="mr-1" />
          Новый чат
        </button>
      </div>
    </header>
  );
};

export default TopBar;
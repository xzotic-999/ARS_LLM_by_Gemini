import React from "react";
import {
  SquareAsterisk,
  Sparkles,
  Search,
  User,
  ChevronLeft,
  ChevronRight,
  Send,
  Square,
  Circle,
  CircleDot,
  AlertTriangle,
  X,
  Menu,
  MessageSquare,
  History,
  Star,
  Copy,
  Pencil,
  Trash2,
  Settings,
  MoreHorizontal,
  Check,
  Plus,
  Minus,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  Moon,
  Sun,
  Paperclip,
  Mic,
  Book,
  HelpCircle,
  Folder,
} from "lucide-react";

interface IconProps {
  name: string;
  size?: number;
  className?: string;
}

type IconComponent = React.FC<{ size?: number | string; className?: string; strokeWidth?: number }>;

const ICONS: Record<string, IconComponent> = {
  logo: SquareAsterisk as unknown as IconComponent,
  newChat: Sparkles as unknown as IconComponent,
  search: Search as unknown as IconComponent,
  user: User as unknown as IconComponent,
  chevronLeft: ChevronLeft as unknown as IconComponent,
  chevronRight: ChevronRight as unknown as IconComponent,
  send: Send as unknown as IconComponent,
  stop: Square as unknown as IconComponent,
  health: Circle as unknown as IconComponent,
  healthOff: CircleDot as unknown as IconComponent,
  error: AlertTriangle as unknown as IconComponent,
  close: X as unknown as IconComponent,
  menu: Menu as unknown as IconComponent,
  message: MessageSquare as unknown as IconComponent,
  history: History as unknown as IconComponent,
  sparkles: Sparkles as unknown as IconComponent,
  star: Star as unknown as IconComponent,
  copy: Copy as unknown as IconComponent,
  edit: Pencil as unknown as IconComponent,
  trash: Trash2 as unknown as IconComponent,
  settings: Settings as unknown as IconComponent,
  more: MoreHorizontal as unknown as IconComponent,
  check: Check as unknown as IconComponent,
  plus: Plus as unknown as IconComponent,
  minus: Minus as unknown as IconComponent,
  arrowUp: ArrowUp as unknown as IconComponent,
  arrowDown: ArrowDown as unknown as IconComponent,
  arrowLeft: ArrowLeft as unknown as IconComponent,
  arrowRight: ArrowRight as unknown as IconComponent,
  moon: Moon as unknown as IconComponent,
  sun: Sun as unknown as IconComponent,
  paperclip: Paperclip as unknown as IconComponent,
  mic: Mic as unknown as IconComponent,
  book: Book as unknown as IconComponent,
  folder: Folder as unknown as IconComponent,
};

export function Icon({ name, size = 16, className = "" }: IconProps) {
  const IconComponent = ICONS[name] || (HelpCircle as unknown as IconComponent);
  return (
    <span className={`inline-flex items-center justify-center ${className}`}>
      <IconComponent size={size} strokeWidth={2} />
    </span>
  );
}

export default Icon;
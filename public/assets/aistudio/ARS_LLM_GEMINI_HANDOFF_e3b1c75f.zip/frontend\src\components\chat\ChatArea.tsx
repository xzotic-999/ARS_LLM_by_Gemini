import React, { useRef, useEffect, useState } from 'react';
import Icon from '../icon';
import './ChatArea.css';

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface ChatAreaProps {
  messages: Message[];
  isLoading?: boolean;
  onExampleSelect?: (text: string) => void;
  onSendMessage?: (text: string) => void;
  disabled?: boolean;
  showWelcome?: boolean;
  chatTitle?: string;
  onNewChat?: () => void;
}

const exampleQueries = [
  'Анализируй мой код и предложи оптимизации производительности',
  'Напиши документацию к этому модулю на русском языке',
  'Объясни концепцию React Server Components простым языком',
  'Напиши тесты для этого компонента с использованием Jest',
];

// ExampleQueries component
const ExampleQueries = ({ onExampleSelect }: { onExampleSelect?: (text: string) => void }) => (
  <div className="example-queries grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 w-full max-w-3xl">
    {exampleQueries.map((text, i) => (
      <button
        key={i}
        className="example-query-btn flex flex-col items-start gap-2 p-4 bg-[color:var(--color-surface-2)] border border-[color:var(--color-border-subtle)] rounded-lg text-left hover:border-[color:var(--color-border-default)] hover:bg-[color:var(--color-surface-3)] transition-colors"
        onClick={() => onExampleSelect && onExampleSelect(text)}
      >
        <span className="text-sm font-medium text-[color:var(--color-text-primary)]">{text}</span>
      </button>
    ))}
  </div>
);

// EmptyState / Welcome screen
const WelcomeScreen = ({ onExampleSelect }: { onExampleSelect?: (text: string) => void }) => {
  const [value, setValue] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const autoGrow = () => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 200) + 'px';
  };

  useEffect(() => {
    autoGrow();
  }, [value]);

  const handleSend = () => {
    const trimmed = value.trim();
    if (!trimmed) return;
    onExampleSelect && onExampleSelect(trimmed);
    setValue('');
    autoGrow();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="welcome-screen flex flex-col items-center text-center flex-1">
      <div className="welcome-content">
        <div className="pill">✦ Ваш рабочий AI-ассистент</div>
        <h1 className="text-display">Здравствуйте! 👋</h1>
        <p className="subtitle">Задавайте вопросы, анализируйте документы и решайте рабочие задачи — в одном пространстве.</p>
      </div>

      <div className="composer-card">
        <div className="composer-head">
          <div className="flex items-center gap-2">
            <Icon name="message" size={18} />
            <span>Начать новый чат</span>
          </div>
          <button className="options-btn" aria-label="Параметры">
            <Icon name="more" size={18} />
          </button>
        </div>
        <div className="composer">
          <textarea
            ref={textareaRef}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Чем я могу помочь вам сегодня?"
            className="composer-textarea"
          />
          <div className="composer-footer">
            <div className="tools">
              <button className="tool-btn">
                <Icon name="paperclip" size={14} className="mr-1" />
                Прикрепить файл
              </button>
              <button className="tool-btn">
                <Icon name="mic" size={14} className="mr-1" />
                Голосовой ввод
              </button>
              <button className="tool-btn">
                <Icon name="book" size={14} className="mr-1" />
                Библиотека промптов
              </button>
            </div>
            <button
              className="send-btn"
              onClick={handleSend}
              disabled={!value.trim()}
              aria-label="Отправить"
            >
              <Icon name="send" size={20} />
            </button>
          </div>
        </div>
      </div>

      <div className="quick">
        <div className="quick-title">С чего начнём?</div>
        <div className="quick-actions">
          {exampleQueries.map((text, i) => (
            <button
              key={i}
              className="quick-action-btn"
              onClick={() => onExampleSelect && onExampleSelect(text)}
            >
              {text}
            </button>
          ))}
        </div>
      </div>

      <div className="footer">ARS LLM · Внутренний корпоративный помощник</div>
    </div>
  );
};

// MessageBubble component
const MessageBubble: React.FC<{
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}> = ({ role, content, timestamp }) => {
  const timeString = timestamp.toLocaleTimeString('ru-RU', {
    hour: '2-digit',
    minute: '2-digit',
  });
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Clipboard API failed silently
    }
  };

  return (
    <div className={`message-bubble flex gap-3 ${role === 'user' ? 'user-message' : 'assistant-message'}`}>
      {role === 'assistant' && (
        <div className="message-avatar flex items-center justify-center w-8 h-8 rounded-lg bg-[color:var(--color-surface-3)] border border-[color:var(--color-border-subtle)] flex-shrink-0">
          <Icon name="message" size={16} className="text-[color:var(--color-accent-primary)]" />
        </div>
      )}
      <div className="message-content flex flex-col gap-1 min-w-0 flex-1">
        <div className="message-meta flex items-center gap-2 text-xs text-[color:var(--color-text-muted)]">
          <span className="font-semibold">{role === 'user' ? 'Вы' : 'ARS LLM'}</span>
          <span aria-hidden="true">·</span>
          <span>{timeString}</span>
          {role === 'assistant' && (
            <button
              type="button"
              onClick={handleCopy}
              aria-label={copied ? 'Скопировано' : 'Копировать'}
              className="copy-btn flex items-center gap-1 px-2 py-1 rounded text-[11px] text-[color:var(--color-text-muted)] hover:text-[color:var(--color-text-primary)] hover:bg-[color:var(--color-surface-2)] transition-colors"
            >
              <Icon name={copied ? 'check' : 'copy'} size={12} />
              <span>{copied ? 'Скопировано' : 'Копировать'}</span>
            </button>
          )}
        </div>
        <div className="message-text leading-relaxed whitespace-pre-wrap break-words">
          {content}
        </div>
      </div>
      {role === 'user' && (
        <div className="message-avatar flex items-center justify-center w-8 h-8 rounded-lg bg-[color:var(--color-surface-3)] border border-[color:var(--color-border-subtle)] flex-shrink-0">
          <Icon name="user" size={16} className="text-[color:var(--color-text-muted)]" />
        </div>
      )}
    </div>
  );
};

// TypingIndicator
const TypingIndicator = () => (
  <div className="typing-indicator flex items-center gap-3 px-1 py-1">
    <div className="typing-avatar flex items-center justify-center w-8 h-8 rounded-lg bg-[color:var(--color-surface-3)] border border-[color:var(--color-border-subtle)] flex-shrink-0">
      <Icon name="message" size={16} className="text-[color:var(--color-accent-primary)]" />
    </div>
    <div className="typing-dots flex gap-1.5">
      <span className="typing-dot w-2 h-2 rounded-full bg-[color:var(--color-accent-primary)] animate-bounce" />
      <span className="typing-dot w-2 h-2 rounded-full bg-[color:var(--color-accent-primary)] animate-bounce" style={{ animationDelay: '0.2s' }} />
      <span className="typing-dot w-2 h-2 rounded-full bg-[color:var(--color-accent-primary)] animate-bounce" style={{ animationDelay: '0.4s' }} />
    </div>
  </div>
);

// ChatComposer for conversation mode
const ChatComposer = ({ onSend, disabled }: { onSend: (text: string) => void; disabled?: boolean }) => {
  const [value, setValue] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const autoGrow = () => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 200) + 'px';
  };

  useEffect(() => {
    autoGrow();
  }, [value]);

  const handleSend = () => {
    const trimmed = value.trim();
    if (!trimmed) return;
    onSend(trimmed);
    setValue('');
    autoGrow();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div id="chatComposer" className="chat-composer">
      <div className="composer-card">
        <div className="composer">
          <textarea
            ref={textareaRef}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Напишите сообщение..."
            rows={1}
            disabled={disabled}
            className="composer-textarea"
            style={{ minHeight: '65px', maxHeight: '200px' }}
          />
          <div className="composer-footer">
            <button
              className="send-btn"
              onClick={handleSend}
              disabled={disabled || !value.trim()}
              aria-label="Отправить сообщение"
            >
              <Icon name="send" size={20} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export const ChatArea: React.FC<ChatAreaProps> = ({ messages, isLoading, onExampleSelect, onSendMessage, disabled, showWelcome, chatTitle = 'Новый чат', onNewChat }) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  return (
    <div className="chat-area flex flex-col h-full min-h-0 bg-[color:var(--color-surface-0)]">
      <div className="chat-container flex-1 overflow-y-auto">
        <div className="chat-inner mx-auto w-full max-w-3xl px-4 py-6">
          {/* Context Bar */}
          {messages.length > 0 && (
            <div className="context-bar flex items-center justify-between gap-4 pb-4 mb-4 border-b border-[color:var(--color-border-subtle)]">
              <div className="flex items-center gap-3 min-w-0">
                {onNewChat && (
                  <button
                    type="button"
                    onClick={onNewChat}
                    aria-label="Назад к списку чатов"
                    className="context-bar-back focus-ring px-3 py-1.5 rounded-lg border border-[color:var(--color-border-default)] text-[13px] font-medium text-[color:var(--color-text-secondary)] hover:bg-[color:var(--color-surface-2)] flex items-center gap-1.5 shrink-0"
                  >
                    <Icon name="arrowLeft" size={16} aria-hidden="true" />
                    <span>Назад</span>
                  </button>
                )}
                <div className="min-w-0">
                  <h2 className="text-[15px] font-semibold text-[color:var(--color-text-primary)] truncate">
                    {chatTitle}
                  </h2>
                  <p className="text-[12px] text-[color:var(--color-text-muted)]">
                    Сообщений: <span className="tabular-nums">{messages.length}</span>
                  </p>
                </div>
              </div>
            </div>
          )}
          {messages.length === 0 && showWelcome ? (
            <WelcomeScreen onExampleSelect={onExampleSelect} />
          ) : (
            <div className="messages flex flex-col gap-5">
              {messages.map((message) => (
                <MessageBubble
                  key={message.id}
                  role={message.role}
                  content={message.content}
                  timestamp={message.timestamp}
                />
              ))}
              {isLoading && <TypingIndicator />}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>
      </div>
      {messages.length > 0 && onSendMessage && (
        <ChatComposer onSend={onSendMessage} disabled={disabled || isLoading} />
      )}
    </div>
  );
};

export default ChatArea;
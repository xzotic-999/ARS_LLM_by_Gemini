import React, { type ReactNode } from 'react';
import { diag } from '../lib/diagnostics';

interface ErrorBoundaryState {
  hasError: boolean;
  error?: Error;
}

export class ErrorBoundary extends React.Component<
  { children: ReactNode; fallback?: ReactNode },
  ErrorBoundaryState
> {
  constructor(props: { children: ReactNode; fallback?: ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    diag.push({
      type: 'error',
      severity: 'high',
      message: error.message || 'Render error',
      stack: error.stack,
      context: { componentStack: info.componentStack?.slice(0, 500) },
    });
  }

  render() {
    if (this.state.hasError) {
      return (
        this.props.fallback ?? (
          <div className="flex h-screen items-center justify-center bg-[color:var(--color-surface-0)] p-6">
            <div className="max-w-md w-full rounded-xl border border-red-500/40 bg-[color:var(--color-surface-1)] p-6 text-center">
              <h2 className="text-lg font-bold text-red-400 mb-2">Что-то пошло не так</h2>
              <p className="text-sm text-[color:var(--color-text-muted)] mb-4">
                Приложение столкнулось с непредвиденной ошибкой. Попробуйте перезагрузить страницу.
              </p>
              <pre className="text-xs text-left bg-black/30 rounded p-3 overflow-auto max-h-40 text-red-300">
                {this.state.error?.stack || this.state.error?.message || 'Unknown error'}
              </pre>
            </div>
          </div>
        )
      );
    }
    return this.props.children;
  }
}

export default ErrorBoundary;
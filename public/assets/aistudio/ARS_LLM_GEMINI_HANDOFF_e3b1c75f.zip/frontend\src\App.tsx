import React, { useState, useEffect } from "react";
import Sidebar from "./components/sidebar";
import TopBar from "./components/topbar";
import { ChatArea, type Message } from "./components/chat/ChatArea";
import { useConversations } from "./contexts/auth";
import { useAuth } from "./contexts/auth";
import type { Conversation } from "./services/conversations";
import LoginPage from "./components/LoginPage";
import ErrorBoundary from "./components/ErrorBoundary";

const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || "").replace(
  /\/+$/,
  ""
);

const App: React.FC = () => {
  const { user, loading: authLoading } = useAuth();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const [messages, setMessages] = useState<Message[]>([]);
  const [activeConversation, setActiveConversation] = useState<Conversation | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isAssistantTyping, setIsAssistantTyping] = useState(false);
  const [showWelcome, setShowWelcome] = useState(true);

  // Hooks must be called unconditionally, before any early returns.
  const {
    conversations,
    messages: historyMessages,
    selectedConversationId,
    setSelectedConversationId,
    loading,
    error,
    createConversation,
    updateConversation,
    deleteConversation,
    sendMessage,
  } = useConversations();

  // Sync local messages with the loaded conversation history.
  useEffect(() => {
    if (historyMessages.length > 0) {
      setMessages(
        historyMessages.map((m) => ({
          id: String(m.id),
          role: m.role,
          content: m.text,
          timestamp: new Date(m.created_at),
        }))
      );
      setShowWelcome(false);
    }
  }, [historyMessages]);

  // Track the currently selected conversation for the dynamic title.
  useEffect(() => {
    if (selectedConversationId === null) {
      setActiveConversation(null);
      return;
    }
    const conv = conversations.find((c) => c.id === selectedConversationId) ?? null;
    setActiveConversation(conv);
  }, [selectedConversationId, conversations]);

  // Derive the title for the top bar.
  const getChatTitle = (): string => {
    if (activeConversation && activeConversation.title) {
      return activeConversation.title;
    }
    if (selectedConversationId !== null && conversations.length > 0) {
      const conv = conversations.find((c) => c.id === selectedConversationId);
      if (conv && conv.title) return conv.title;
    }
    return "Новый чат";
  };

  // Show loading state
  if (authLoading) {
    return (
      <div className="flex h-screen items-center justify-center bg-[color:var(--color-surface-0)]">
        <div className="text-[color:var(--color-text-muted)]">Loading...</div>
      </div>
    );
  }

  // Show login page if not authenticated yet
  if (!user) {
    return <LoginPage />;
  }

  const handleSend = async (content: string) => {
    if (isAssistantTyping) return;

    let conversationId = selectedConversationId;
    const userMessage: Message = {
      id: crypto.randomUUID(),
      role: "user",
      content,
      timestamp: new Date(),
    };

    const assistantId = crypto.randomUUID();

    setMessages((prev) => [...prev, userMessage]);
    setIsAssistantTyping(true);
    setShowWelcome(false);

    try {
      // Ensure a conversation exists before sending.
      if (conversationId === null) {
        const newConv = await createConversation(content.slice(0, 60) || "Новый чат");
        if (!newConv) {
          throw new Error("Не удалось создать беседу.");
        }
        conversationId = newConv.id;
      }

      // Persist the user message.
      await sendMessage(conversationId, "user", content);

      const conversation = [
        ...messages.map(({ role, content }) => ({ role, content })),
        { role: userMessage.role, content: userMessage.content },
      ];

      const response = await fetch(`${API_BASE_URL}/api/v1/chat/completions`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "text/event-stream",
        },
        credentials: "include",
        body: JSON.stringify({
          messages: conversation,
          stream: true,
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Backend вернул HTTP ${response.status}: ${errorText.slice(0, 500)}`);
      }

      if (!response.body) {
        throw new Error("Backend не вернул поток ответа.");
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let answer = "";
      let streamFinished = false;

      const appendContent = (text: string) => {
        answer += text;
        setMessages((prev) => {
          const exists = prev.some((msg) => msg.id === assistantId);
          if (!exists) {
            return [
              ...prev,
              { id: assistantId, role: "assistant", content: answer, timestamp: new Date() },
            ];
          }
          return prev.map((msg) => (msg.id === assistantId ? { ...msg, content: answer } : msg));
        });
      };

      const processEvent = (event: string) => {
        const data = event
          .split(/\r?\n/)
          .filter((line) => line.startsWith("data:"))
          .map((line) => line.slice(5).trimStart())
          .join("\n");
        if (!data) return;
        if (data === "[DONE]") {
          streamFinished = true;
          return;
        }
        const payload = JSON.parse(data);
        if (payload.error) {
          throw new Error(
            typeof payload.error === "string"
              ? payload.error
              : payload.error.message || "Ошибка генерации модели."
          );
        }
        const delta = payload.choices?.[0]?.delta?.content;
        if (typeof delta === "string" && delta.length > 0) {
          appendContent(delta);
        }
      };

      while (!streamFinished) {
        const { value, done } = await reader.read();
        if (done) {
          buffer += decoder.decode();
          break;
        }
        buffer += decoder.decode(value, { stream: true });
        const events = buffer.split(/\r?\n\r?\n/);
        buffer = events.pop() ?? "";
        for (const event of events) {
          processEvent(event);
          if (streamFinished) break;
        }
      }

      if (!streamFinished && buffer.trim()) {
        processEvent(buffer);
      }

      const finalAnswer = answer.trim() || "Модель завершила ответ без текста.";

      // Persist the assistant reply exactly once.
      if (conversationId !== null) {
        await sendMessage(conversationId, "assistant", finalAnswer);
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Неизвестная ошибка";
      const content = `Не удалось получить ответ от ИИ.\n${errorMessage}`;
      setMessages((prev) => {
        const exists = prev.some((msg) => msg.id === assistantId);
        if (!exists) {
          return [...prev, { id: assistantId, role: "assistant", content, timestamp: new Date() }];
        }
        return prev.map((msg) =>
          msg.id === assistantId ? { ...msg, content: msg.content + `\n${content}` } : msg
        );
      });
    } finally {
      setIsAssistantTyping(false);
    }
  };

  const handleNewChat = () => {
    setMessages([]);
    setIsAssistantTyping(false);
    setShowWelcome(true);
    setSelectedConversationId(null);
    setActiveConversation(null);
    setSearchQuery("");
  };

  const handleRenameConversation = async (id: number, newTitle: string) => {
    const updated = await updateConversation(id, newTitle);
    if (updated) {
      setActiveConversation((prev) =>
        prev && prev.id === id ? { ...prev, title: newTitle } : prev
      );
    }
  };

  const handleDeleteConversation = async (id: number) => {
    await deleteConversation(id);
    if (activeConversation && activeConversation.id === id) {
      setActiveConversation(null);
    }
  };

  return (
    <ErrorBoundary>
      <div className={`app${sidebarCollapsed ? ' collapsed' : ''}`}>
        <Sidebar
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          onRename={handleRenameConversation}
          onDelete={handleDeleteConversation}
          collapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed((prev) => !prev)}
        />
        <main className="main flex flex-col min-h-0">
          <TopBar
            onNewChatClick={handleNewChat}
            user={user}
            chatTitle={getChatTitle()}
          />
          <ChatArea
            messages={messages}
            isLoading={isAssistantTyping || loading}
            onExampleSelect={handleSend}
            onSendMessage={handleSend}
            disabled={isAssistantTyping}
            showWelcome={showWelcome && messages.length === 0}
            chatTitle={getChatTitle()}
            onNewChat={handleNewChat}
          />
        </main>
      </div>
    </ErrorBoundary>
  );
};

export default App;
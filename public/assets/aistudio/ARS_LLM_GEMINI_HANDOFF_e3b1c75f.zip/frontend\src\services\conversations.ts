
export interface Conversation {
  id: number;
  title: string;
  created_at: string; // ISO string
  last_message_at: string; // ISO string
}

export interface ConversationMessage {
  id: number;
  conversation_id: number;
  role: 'user' | 'assistant';
  text: string;
  created_at: string; // ISO string
}

const fetchWithAuth = async (url: string, options: RequestInit = {}): Promise<Response> => {
  const response = await fetch(url, {
    ...options,
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
  });

  if (!response.ok) {
    // Lazy import to avoid circular dependency with diagnostics module.
    try {
      const { diag } = await import('../lib/diagnostics');
      diag.push({
        type: 'api',
        severity: response.status >= 500 ? 'high' : 'medium',
        message: `API ${options.method || 'GET'} ${url} failed`,
        context: {
          method: options.method || 'GET',
          url,
          status: response.status,
          statusText: response.statusText,
        },
      });
    } catch {
      // Diagnostics must never break the app.
    }
  }

  return response;
};

export const conversationsApi = {
  // GET /api/v1/conversations?user_id=X
  list: async (userId: number): Promise<Conversation[]> => {
    const response = await fetchWithAuth(`/api/v1/conversations?user_id=${userId}`);
    if (!response.ok) {
      throw new Error(`Failed to fetch conversations: ${response.status}`);
    }
    return response.json();
  },

  // GET /api/v1/conversations/:id
  get: async (id: number): Promise<Conversation> => {
    const response = await fetchWithAuth(`/api/v1/conversations/${id}`);
    if (!response.ok) {
      throw new Error(`Failed to fetch conversation: ${response.status}`);
    }
    return response.json();
  },

  // POST /api/v1/conversations
  create: async (title: string, userId?: number): Promise<Conversation> => {
    const response = await fetchWithAuth('/api/v1/conversations', {
      method: 'POST',
      body: JSON.stringify({ title, user_id: userId }),
    });
    if (!response.ok) {
      throw new Error(`Failed to create conversation: ${response.status}`);
    }
    return response.json();
  },

  // PATCH /api/v1/conversations/:id
  update: async (id: number, title: string): Promise<Conversation> => {
    const response = await fetchWithAuth(`/api/v1/conversations/${id}`, {
      method: 'PATCH',
      body: JSON.stringify({ title }),
    });
    if (!response.ok) {
      throw new Error(`Failed to update conversation: ${response.status}`);
    }
    return response.json();
  },

  // DELETE /api/v1/conversations/:id
  delete: async (id: number): Promise<void> => {
    const response = await fetchWithAuth(`/api/v1/conversations/${id}`, {
      method: 'DELETE',
    });
    if (!response.ok) {
      throw new Error(`Failed to delete conversation: ${response.status}`);
    }
  },
};

export const messagesApi = {
  // GET /api/v1/messages?conversation_id=X
  list: async (conversationId: number): Promise<ConversationMessage[]> => {
    const response = await fetchWithAuth(`/api/v1/messages?conversation_id=${conversationId}`);
    if (!response.ok) {
      throw new Error(`Failed to fetch messages: ${response.status}`);
    }
    return response.json();
  },

  // POST /api/v1/messages
  create: async (
    conversationId: number,
    role: 'user' | 'assistant' | 'system',
    text: string,
    userId?: number
  ): Promise<ConversationMessage> => {
    const response = await fetchWithAuth('/api/v1/messages', {
      method: 'POST',
      body: JSON.stringify({
        conversation_id: conversationId,
        role,
        text,
        user_id: userId,
      }),
    });
    if (!response.ok) {
      throw new Error(`Failed to create message: ${response.status}`);
    }
    return response.json();
  },
};
import React, { useState } from "react";
import { useAuth } from "../../contexts/auth";
import Icon from "../icon";

// Custom email validation that allows internal domains (.local) and underscores
// in hostnames, which HTML5's type="email" rejects but are valid for this system.
function isValidEmail(value: string): boolean {
  if (!value || value.trim().length === 0) return false;
  if (value.length > 254) return false;

  const trimmed = value.trim();
  const atIdx = trimmed.lastIndexOf("@");
  if (atIdx <= 0 || atIdx === trimmed.length - 1) return false;

  const local = trimmed.slice(0, atIdx);
  const domain = trimmed.slice(atIdx + 1);

  if (local.length === 0 || domain.length === 0) return false;
  if (local.length > 64 || domain.length > 253) return false;
  if (domain.includes(" ")) return false;
  if (domain.includes("@")) return false;
  if (!domain.includes(".")) return false;

  // Reject empty or whitespace-only labels
  const labels = domain.split(".");
  for (const label of labels) {
    if (label.length === 0) return false;
  }

  return true;
}

export const LoginPanel: React.FC = () => {
  const { login, error, clearError } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [emailError, setEmailError] = useState<string | null>(null);

  const validateEmail = (value: string) => {
    if (isValidEmail(value)) {
      setEmailError(null);
    } else {
      setEmailError("Enter a valid email address.");
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isValidEmail(email)) {
      setEmailError("Enter a valid email address.");
      return;
    }
    setSubmitting(true);
    clearError();
    try {
      await login(email, password);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex items-center justify-center h-screen bg-[color:var(--color-surface-0)]">
      <div className="w-full max-w-sm mx-4 bg-[color:var(--color-surface-1)] border border-[color:var(--color-border-default)] rounded-xl p-6 shadow-lg">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-lg bg-[color:var(--color-surface-3)] border border-[color:var(--color-border-default)] flex items-center justify-center">
            <Icon name="logo" size={20} className="text-[color:var(--color-accent-primary)]" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-[color:var(--color-text-primary)]">ARS_LLM</h1>
            <p className="text-xxs text-[color:var(--color-text-muted)]">Nebula AI</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label
              htmlFor="login-email"
              className="block text-xs text-[color:var(--color-text-muted)] mb-1"
            >
              Email
            </label>
            <input
              id="login-email"
              type="text"
              inputMode="email"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                if (emailError) validateEmail(e.target.value);
              }}
              onBlur={() => validateEmail(email)}
              required
              className="w-full px-3 py-2 rounded-md bg-[color:var(--color-surface-2)] border border-[color:var(--color-border-default)] text-[color:var(--color-text-primary)] text-sm focus:outline-none focus:ring-2 focus:ring-[color:var(--color-accent-primary)]"
            />
            {emailError && (
              <p className="text-xs text-red-500 mt-1" role="alert">
                {emailError}
              </p>
            )}
          </div>
          <div>
            <label
              htmlFor="login-password"
              className="block text-xs text-[color:var(--color-text-muted)] mb-1"
            >
              Password
            </label>
            <input
              id="login-password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="w-full px-3 py-2 rounded-md bg-[color:var(--color-surface-2)] border border-[color:var(--color-border-default)] text-[color:var(--color-text-primary)] text-sm focus:outline-none focus:ring-2 focus:ring-[color:var(--color-accent-primary)]"
            />
          </div>

          {error && (
            <p className="text-xs text-red-500" role="alert">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-2 rounded-md bg-[color:var(--color-accent-primary)] text-white text-sm font-medium hover:opacity-90 transition-opacity disabled:opacity-50"
          >
            {submitting ? "Entering..." : "Sign in"}
          </button>
        </form>
      </div>
    </div>
  );
};

export default LoginPanel;